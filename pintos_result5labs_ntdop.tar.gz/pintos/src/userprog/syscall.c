#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"


#include "devices/shutdown.h"
#include "userprog/process.h"
#include "threads/vaddr.h"
#include "lib/string.h"

typedef int pid_t;
void* eax;

static void syscall_handler (struct intr_frame *);
void syscall_exit(int process);

void
validate_user_pointer(const void* f_esp){
  if (is_kernel_vaddr(f_esp) || (pagedir_get_page(thread_current()->pagedir, f_esp) == NULL)){
    syscall_exit(-1);
    return;
  }
  return;
}


void
syscall_halt(void)
{
  shutdown_power_off();
}

void
syscall_exit(int process){

  thread_current()->exit_prs = process;
  eax = process;
  thread_exit();
}


pid_t
syscall_exec (const char *cmd_line){

  char* file_name = (char*)malloc(17);
  strlcpy(file_name, (const char*) cmd_line, 17);
  char* name;
  file_name = strtok_r(file_name, " ", &name);

  //printf("%s\n", file_name);
  struct file* file_on_disk = filesys_open(file_name);
  if (!file_on_disk){
    //f->eax = -1;
    //printf("-----\n");
    return -1;
  }
  file_close(file_on_disk);
  return process_execute(cmd_line);
} 


int
syscall_open(const char* file){
  //printf("-----\n");
  struct file* file_name = filesys_open(file);
  if (file_name != NULL){
    struct thread* cur = thread_current();
    struct file_str* ns_file = (struct file_str*)malloc(sizeof(struct file_str));
    ns_file->file_name = file_name;
    ns_file->file_des = cur->number_of_file_proc;
    ns_file->flag_continue = 1;

    cur->number_of_file_proc += 1;
    list_push_back(&cur->fl_list, &ns_file->file_elem);
    //printf(">>>%d\n", ns_file->file_des);
    return ns_file->file_des;

  }
  return -1;
}

int
syscall_close(int fd){
  if (fd != 0 && fd != 1){
    struct thread* cur = thread_current();
    for (struct list_elem *e = list_begin(&cur->fl_list); e != list_end(&cur->fl_list); e = list_next(e)){
      struct file_str* ns_file = list_entry(e, struct file_str, file_elem);
      if (ns_file->file_name == NULL){
        return -1;
      }
      if (ns_file->file_des == fd && ns_file->file_name != NULL){
        //printf("%s\n", ns_file->file_name);
        file_close(ns_file->file_name);
        list_remove(&ns_file->file_elem);
        free(ns_file);
        return 1;
      }
    }
  }
  return -1;
}


int syscall_filesize(int fd){
  struct thread* cur = thread_current();
    for (struct list_elem *e = list_begin(&cur->fl_list); e != list_end(&cur->fl_list); e = list_next(e)){
      struct file_str* ns_file = list_entry(e, struct file_str, file_elem);
      if (ns_file->file_des == fd){
        return file_length(ns_file->file_name);
      }
    }

  return -1;
}


int syscall_read(int fd, void *buffer, unsigned size){
  struct thread* cur = thread_current();
  for (struct list_elem *e = list_begin(&cur->fl_list); e != list_end(&cur->fl_list); e = list_next(e)){
    struct file_str* ns_file = list_entry(e, struct file_str, file_elem);
    if (ns_file->file_des == fd){
      return file_read(ns_file->file_name, buffer, size);
    }
  }
  return -1;
}

int syscall_write(int fd, void *buffer, unsigned size){
  struct thread* cur = thread_current();
  for (struct list_elem *e = list_begin(&cur->fl_list); e != list_end(&cur->fl_list); e = list_next(e)){
    struct file_str* ns_file = list_entry(e, struct file_str, file_elem);
    if (ns_file->file_des == fd){
      return file_write(ns_file->file_name, buffer, size);
    }
  }
  return -1;
}

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}



static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  //int exit_status;
  char* file_name;
  //char* name;
  validate_user_pointer((const void*) f->esp);
  int process = *(int*)f->esp;


  int* args = (int*)f->esp + 1;
  validate_user_pointer(args);
  validate_user_pointer(args + 1);
  validate_user_pointer(args + 2);
  eax = f->eax;

  //validate_user_pointer((const void*) f->esp);

  switch(process) {

  case SYS_HALT:
    syscall_halt();
    break;

  case SYS_EXIT:
    syscall_exit(args[0]);
    break;

  case SYS_EXEC:
    validate_user_pointer((const char*) args[0]);
    f->eax = syscall_exec((const char*) args[0]);
    break;

  /*case SYS_WRITE:
    putbuf(((const char**) f -> esp)[2], ((size_t*) f->esp)[3]);
    break;*/

  case SYS_WAIT:
    //validate_user_pointer((const char*) args[0]);
    f->eax = process_wait(args[0]);
    break;

  case SYS_CREATE:
    validate_user_pointer((const char*) args[0]);
    f->eax = filesys_create((const char*) args[0], (unsigned)args[1]);
    break;

  case SYS_REMOVE:
    validate_user_pointer((const char*) args[0]);
    f->eax = filesys_remove((const char*) args[0]);
    break;


  case SYS_OPEN:
    validate_user_pointer((const char*) args[0]);
    f->eax = syscall_open((const char*) args[0]);
    break;


  case SYS_CLOSE:
    if (syscall_close(args[0]) == -1){
      f->eax = -1;
    }
    break;


  case SYS_FILESIZE:
    f->eax = syscall_filesize(args[0]);
    break;


  case SYS_READ:
    validate_user_pointer((const void*) args[1]);
    validate_user_pointer((const void*) (args[1] + args[2]));
    if (args[0] == 0){
      for (int i = 0; i < args[2]; i++){
        f->eax = input_getc();
      }
      f->eax = args[2];
      break;
    }

    f->eax = syscall_read(args[0], (void*) args[1], (unsigned) args[2]);
    break;


  case SYS_WRITE:
    validate_user_pointer((const void*) args[1]);
    validate_user_pointer((const void*) (args[1] + args[2]));
    if (args[0] == 1){
      putbuf(((const char**) f->esp)[2], ((size_t*) f->esp)[3]);
      f->eax = args[2];
      break;

    }

    f->eax = syscall_write(args[0], (void*) args[1], (unsigned) args[2]);
    break;




  }


  
}
